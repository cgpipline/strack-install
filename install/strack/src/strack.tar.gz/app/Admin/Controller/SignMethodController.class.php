<?php
namespace Admin\Controller;

// +----------------------------------------------------------------------
// | 项目模板数据控制层
// +----------------------------------------------------------------------

class SignMethodController extends AdminController
{

    /**
     * 显示页面
     */
    public function index()
    {
        return $this->display();
    }

}