<?php
namespace Admin\Controller;


class UpgradeController extends AdminController
{

}