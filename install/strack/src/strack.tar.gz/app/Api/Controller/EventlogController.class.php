<?php

namespace Api\Controller;


class EventlogController extends  BaseController
{

}
