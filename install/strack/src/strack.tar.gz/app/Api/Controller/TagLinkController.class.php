<?php

namespace Api\Controller;


class TagLinkController extends BaseController
{

}
