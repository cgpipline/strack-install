<?php

namespace Api\Controller;


class DirVariableController extends BaseController
{

}
