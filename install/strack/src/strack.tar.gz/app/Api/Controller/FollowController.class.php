<?php

namespace Api\Controller;


class FollowController extends BaseController
{

}
