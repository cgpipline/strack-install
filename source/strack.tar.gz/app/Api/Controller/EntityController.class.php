<?php

namespace Api\Controller;


class EntityController extends BaseController
{

}