<?php

namespace Api\Controller;


class MediaServerController extends  BaseController
{

}
