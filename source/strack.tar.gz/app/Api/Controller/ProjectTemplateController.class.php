<?php

namespace Api\Controller;


class ProjectTemplateController extends BaseController
{

}
