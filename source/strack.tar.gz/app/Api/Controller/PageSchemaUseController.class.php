<?php

namespace Api\Controller;


class PageSchemaUseController extends BaseController
{

}
