<?php

namespace Api\Controller;


class PlanController extends  BaseController
{

}
