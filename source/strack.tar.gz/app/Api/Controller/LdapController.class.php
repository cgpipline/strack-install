<?php

namespace Api\Controller;


class LdapController extends  BaseController
{

}
