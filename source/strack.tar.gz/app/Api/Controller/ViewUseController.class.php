<?php
namespace Api\Controller;

class ViewUseController extends BaseController
{

}