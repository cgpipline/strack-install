<?php
return [
    'app_begin' => ['Behavior\CheckLangBehavior'],
    'action_end'=> ['Common\Behaviors\EndControllerBehavior'],
];
