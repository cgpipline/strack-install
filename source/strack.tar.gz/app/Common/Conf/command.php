<?php
return [
    'Common\Command\MessageCommand', // 执行消息命令
    'Common\Command\EmailCommand', // 执行消息命令
    'Common\Command\AddMediaServerCommand', // 执行媒体服务添加
];
